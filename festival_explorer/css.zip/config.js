var api = 'http://206.189.115.142:8349';
var blockTargetInterval = 120;
var coinUnits = 100000000;
var symbol = 'FEST';
var refreshDelay = 30000;
var networkStat = {
    'fest': [
       ['festival.multiminer.us', "https://festival.multiminer.us:8119"],
       ['youpool.io/FEST', "https://youpool.io:8116"]
    ]
};
